<?php 

class expense{

	public function __construct(){

		$this->link=mysqli_connect('localhost','root','','expense');

	}
	public function catch($data){
          $dates=$_POST['dates'];
          $description=$_POST['description'];
          $cash_in=$_POST['cash_in'];
          $cash_out=$_POST['cash_out'];
          
          $sql="INSERT INTO income(transaction_date,description,cash_in,cash_out) VALUES ('$dates','$description','$cash_in','$cash_out')";         
          mysqli_query($this->link,$sql);
        }
}


?>