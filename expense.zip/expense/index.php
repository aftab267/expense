<?php 
require('classes/expense.php');
$test=new expense();

if(isset($_POST['save_user'])){
	
	$test->catch($_POST);
}



?>






<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Expense Management System</title>
</head>
<body>
<form action="" method="POST">
	<input type="date" name="dates" placeholder="date"><br><br>
	<input type="text" name="description" placeholder="Description"><br><br>
     <input type="text" name="cash_in" placeholder="cash in"><br><br>
     <input type="text" name="cash_out" placeholder="cash out"><br><br>
     <input type="submit" name="save_user" value="save_user">




</form>



</body>
</html>